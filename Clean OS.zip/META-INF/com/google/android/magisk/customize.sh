#Magisk modules use $MODPATH as main path
#Your script starts here:
